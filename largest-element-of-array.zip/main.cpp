
#include <iostream>
#include<bits/stdc++.h>
using namespace std;

int main()
{
    int largarr[]={22,100,42,56,11};
    int n=sizeof(largarr)/sizeof(largarr[0]);
    sort(largarr,largarr+n);
    int largest=largarr[n-1];
    cout<<"Largest element is:"<<largest;
}

//We have not used .begin() and .end() because we have array here and for it stl sort is arr and arr+n.
//But we did that in case of string because string is treated as class in cpp just like vector.
//But we can use sort(begin(largarr),end(largarr)); According to stl.
    